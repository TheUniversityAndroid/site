const {ipcRenderer} = require('electron');
const BrowserWindow = require('electron').remote.BrowserWindow

if (typeof commands === "undefined") {
  commands = [];
}

if (typeof next === "undefined") {
  next = null;
}

if (typeof previous === "undefined") {
  previous = null;
}

ipcRenderer.send("com.universityandroid.commands", commands);

ipcRenderer.on("com.universityandroid.events", (event, message) => {
  const moveToPage = (pageToLoad) => {    
    const mainBrowserWindow = BrowserWindow.fromId(message.browserWindowId)
    mainBrowserWindow.loadURL(`file://${__dirname}/${pageToLoad}`);
  }
  if (message.name === "NextPage" && next) {
    moveToPage(next);
  } else if (message.name === "PreviousPage" && previous){
    moveToPage(previous);
  } else {
    ipcRenderer.send("com.universityandroid.commands", []);
  }
});