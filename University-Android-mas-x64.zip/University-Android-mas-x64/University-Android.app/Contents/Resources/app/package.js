const packager = require('electron-packager')
const exec = require('child_process').exec;

const zipDistro = (distroName) => {
  exec(`zip -ry ${distroName}.zip ${distroName}`, {maxBuffer: 1024 * 1000}, (err, stout, stderr) => {
    if (err && err.code !== 0) { throw err; }
    console.log(`successfully zipped ${distroName}`);
  })
}

packager({arch: "x64", dir: ".", platform: "all", overwrite: true}, (err, appPaths) => {
  if (err) {
    throw err;
  }
  zipDistro("University-Android-win32-x64");
  zipDistro("University-Android-mas-x64");
  zipDistro("University-Android-linux-x64");
})