electron-packager . --all --overwrite
