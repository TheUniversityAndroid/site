const {shell} = require('electron');

const nodeList = document.querySelectorAll("a")
if (nodeList.length > 0) {
  const links = Array.prototype.slice.call(nodeList, 0);

  const openInExternal = (event) => {
    event.preventDefault();
    shell.openExternal(event.target.getAttribute("href"));
  }

  links.filter((link) => {
    const protocol = link.getAttribute("href").split("://")[0];
    return protocol === "http" || protocol === "https"
  }).forEach((link) => {
    link.addEventListener("click", openInExternal);
  });
}